/**
 * Profile page functionality for the CardTrade platform
 * Handles user profile settings, payment methods and preferences
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize profile settings form
    initProfileForm();
    
    // Initialize payment methods management
    initPaymentMethods();
    
    // Initialize notification preferences
    initNotificationPreferences();
    
    // Initialize security settings
    initSecuritySettings();
    
    // Initialize transaction history
    initTransactionHistory();
    
    // Initialize avatar upload
    initAvatarUpload();
});

/**
 * Initialize profile settings form
 */
function initProfileForm() {
    const profileForm = document.getElementById('profile-form');
    if (!profileForm) return;
    
    // Form validation
    profileForm.addEventListener('submit', function(e) {
        let isValid = true;
        
        // Clear previous error messages
        const errorMessages = profileForm.querySelectorAll('.error-message');
        errorMessages.forEach(el => el.remove());
        
        // Reset input styles
        const inputs = profileForm.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.classList.remove('border-red-500', 'bg-red-50');
            input.classList.remove('border-green-500', 'bg-green-50');
        });
        
        // Validate email
        const emailInput = document.getElementById('email');
        if (emailInput && !validateEmail(emailInput.value)) {
            isValid = false;
            showValidationError(emailInput, 'Please enter a valid email address');
        }
        
        // Validate phone (if present)
        const phoneInput = document.getElementById('phone');
        if (phoneInput && phoneInput.value && !validatePhone(phoneInput.value)) {
            isValid = false;
            showValidationError(phoneInput, 'Please enter a valid phone number');
        }
        
        // Validate username (if present)
        const usernameInput = document.getElementById('username');
        if (usernameInput && usernameInput.value.length < 3) {
            isValid = false;
            showValidationError(usernameInput, 'Username must be at least 3 characters');
        }
        
        // If validation fails, prevent form submission
        if (!isValid) {
            e.preventDefault();
            
            // Scroll to the first error
            const firstError = profileForm.querySelector('.error-message');
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            
            // Show toast notification
            if (typeof showToast === 'function') {
                showToast('Please fix the errors in the form before submitting', 'error');
            }
        } else {
            // Add success feedback for valid inputs
            inputs.forEach(input => {
                if (input.value.trim() !== '') {
                    input.classList.add('border-green-500');
                }
            });
            
            // Show loading state on submit button
            const submitBtn = profileForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                const originalText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = `
                    <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Saving...
                `;
                
                // Reset button after a timeout (in case form submission takes too long)
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }, 10000);
            }
        }
    });
    
    // Email validation helper
    function validateEmail(email) {
        const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    
    // Phone validation helper
    function validatePhone(phone) {
        const re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
        return re.test(String(phone));
    }
    
    // Display validation error
    function showValidationError(element, message) {
        // Highlight input
        element.classList.add('border-red-500', 'bg-red-50');
        
        // Add error message
        const errorMessage = document.createElement('p');
        errorMessage.classList.add('text-red-500', 'text-sm', 'mt-1', 'error-message', 'animate-fade-in');
        errorMessage.textContent = message;
        
        // Insert after the element or its parent label/container
        const container = element.closest('.form-group') || element.parentNode;
        container.appendChild(errorMessage);
        
        // Add shake animation to element
        element.classList.add('shake');
        setTimeout(() => {
            element.classList.remove('shake');
        }, 500);
    }
    
    // Real-time validation feedback
    const emailInput = document.getElementById('email');
    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            if (this.value && !validateEmail(this.value)) {
                this.classList.add('border-red-500', 'bg-red-50');
                
                // Remove any existing error message
                const existingError = this.parentNode.querySelector('.error-message');
                if (existingError) existingError.remove();
                
                showValidationError(this, 'Please enter a valid email address');
            } else if (this.value) {
                this.classList.remove('border-red-500', 'bg-red-50');
                this.classList.add('border-green-500');
                
                // Remove any existing error message
                const existingError = this.parentNode.querySelector('.error-message');
                if (existingError) existingError.remove();
            }
        });
    }
    
    // Same for phone
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('blur', function() {
            if (this.value && !validatePhone(this.value)) {
                this.classList.add('border-red-500', 'bg-red-50');
                
                // Remove any existing error message
                const existingError = this.parentNode.querySelector('.error-message');
                if (existingError) existingError.remove();
                
                showValidationError(this, 'Please enter a valid phone number');
            } else if (this.value) {
                this.classList.remove('border-red-500', 'bg-red-50');
                this.classList.add('border-green-500');
                
                // Remove any existing error message
                const existingError = this.parentNode.querySelector('.error-message');
                if (existingError) existingError.remove();
            }
        });
    }
}

/**
 * Initialize payment methods management
 */
function initPaymentMethods() {
    const paymentMethodsSection = document.getElementById('payment-methods');
    if (!paymentMethodsSection) return;
    
    const addMethodButton = document.getElementById('add-payment-method');
    const methodForm = document.getElementById('payment-method-form');
    const methodTypeSelect = document.getElementById('payment-method-type');
    const methodFormFields = document.getElementById('payment-method-fields');
    const cancelAddButton = document.getElementById('cancel-add-method');
    const deleteButtons = document.querySelectorAll('.delete-payment-method');
    
    // Show payment method form
    if (addMethodButton && methodForm) {
        addMethodButton.addEventListener('click', function() {
            addMethodButton.classList.add('hidden');
            methodForm.classList.remove('hidden');
            methodForm.classList.add('animate-fade-in');
        });
    }
    
    // Cancel adding a payment method
    if (cancelAddButton && methodForm && addMethodButton) {
        cancelAddButton.addEventListener('click', function() {
            methodForm.classList.add('animate-fade-out');
            
            setTimeout(() => {
                methodForm.classList.add('hidden');
                methodForm.classList.remove('animate-fade-out');
                addMethodButton.classList.remove('hidden');
                addMethodButton.classList.add('animate-fade-in');
                
                // Reset form
                methodForm.reset();
                if (methodFormFields) {
                    methodFormFields.innerHTML = '';
                }
            }, 300);
        });
    }
    
    // Change form fields based on payment method type
    if (methodTypeSelect && methodFormFields) {
        methodTypeSelect.addEventListener('change', function() {
            const methodType = this.value;
            
            // Show loading state
            methodFormFields.innerHTML = `
                <div class="flex justify-center py-4">
                    <svg class="animate-spin h-8 w-8 text-primary-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                </div>
            `;
            
            // Simulate loading delay
            setTimeout(() => {
                let fieldsHTML = '';
                
                if (methodType === 'bank') {
                    fieldsHTML = `
                        <div class="form-group mb-4">
                            <label for="bank-name" class="form-label">Bank Name</label>
                            <input type="text" id="bank-name" name="bank_name" class="form-input" required>
                        </div>
                        <div class="form-group mb-4">
                            <label for="account-name" class="form-label">Account Holder Name</label>
                            <input type="text" id="account-name" name="account_name" class="form-input" required>
                        </div>
                        <div class="form-group mb-4">
                            <label for="account-number" class="form-label">Account Number</label>
                            <input type="text" id="account-number" name="account_number" class="form-input" required>
                        </div>
                        <div class="form-group mb-4">
                            <label for="routing-number" class="form-label">Routing Number</label>
                            <input type="text" id="routing-number" name="routing_number" class="form-input" required>
                        </div>
                    `;
                } else if (methodType === 'paypal') {
                    fieldsHTML = `
                        <div class="form-group mb-4">
                            <label for="paypal-email" class="form-label">PayPal Email</label>
                            <input type="email" id="paypal-email" name="paypal_email" class="form-input" required>
                        </div>
                    `;
                } else if (methodType === 'crypto') {
                    fieldsHTML = `
                        <div class="form-group mb-4">
                            <label for="crypto-type" class="form-label">Cryptocurrency</label>
                            <select id="crypto-type" name="crypto_type" class="form-select" required>
                                <option value="">Select Cryptocurrency</option>
                                <option value="btc">Bitcoin (BTC)</option>
                                <option value="eth">Ethereum (ETH)</option>
                                <option value="ltc">Litecoin (LTC)</option>
                                <option value="xrp">Ripple (XRP)</option>
                                <option value="usdt">Tether (USDT)</option>
                            </select>
                        </div>
                        <div class="form-group mb-4">
                            <label for="wallet-address" class="form-label">Wallet Address</label>
                            <input type="text" id="wallet-address" name="wallet_address" class="form-input" required>
                        </div>
                    `;
                }
                
                // Add save button
                fieldsHTML += `
                    <div class="flex justify-end space-x-4 mt-6">
                        <button type="button" id="cancel-add-method" class="btn btn-outline">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Payment Method</button>
                    </div>
                `;
                
                // Add the fields to the form with animation
                methodFormFields.innerHTML = fieldsHTML;
                
                // Reinitialize cancel button
                const newCancelButton = document.getElementById('cancel-add-method');
                if (newCancelButton && methodForm && addMethodButton) {
                    newCancelButton.addEventListener('click', function() {
                        methodForm.classList.add('animate-fade-out');
                        
                        setTimeout(() => {
                            methodForm.classList.add('hidden');
                            methodForm.classList.remove('animate-fade-out');
                            addMethodButton.classList.remove('hidden');
                            addMethodButton.classList.add('animate-fade-in');
                            
                            // Reset form
                            methodForm.reset();
                            methodFormFields.innerHTML = '';
                        }, 300);
                    });
                }
                
                // Add animation
                methodFormFields.classList.add('animate-fade-in');
            }, 800);
        });
    }
    
    // Delete payment method functionality
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const methodId = this.getAttribute('data-method-id');
            const methodCard = this.closest('.payment-method-card');
            
            if (!methodId || !methodCard) return;
            
            // Confirm deletion
            if (confirm('Are you sure you want to delete this payment method?')) {
                // Show loading state
                this.innerHTML = `
                    <svg class="animate-spin h-4 w-4 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                `;
                this.disabled = true;
                
                // Simulate API call to delete payment method
                setTimeout(() => {
                    // Remove the payment method card with animation
                    methodCard.classList.add('animate-fade-out');
                    
                    setTimeout(() => {
                        methodCard.remove();
                        
                        // Show success toast
                        if (typeof showToast === 'function') {
                            showToast('Payment method deleted successfully', 'success');
                        }
                        
                        // Check if there are no payment methods left
                        const remainingMethods = document.querySelectorAll('.payment-method-card');
                        if (remainingMethods.length === 0) {
                            const emptyState = document.createElement('div');
                            emptyState.classList.add('text-center', 'py-6', 'animate-fade-in');
                            emptyState.innerHTML = `
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                                </svg>
                                <p class="text-gray-500">No payment methods added</p>
                                <p class="text-gray-400 text-sm mt-1">Add a payment method to receive payments</p>
                            `;
                            
                            const methodsContainer = document.querySelector('.payment-methods-container');
                            if (methodsContainer) {
                                methodsContainer.appendChild(emptyState);
                            }
                        }
                    }, 300);
                }, 1000);
            }
        });
    });
}

/**
 * Initialize notification preferences
 */
function initNotificationPreferences() {
    const notificationToggles = document.querySelectorAll('.notification-toggle');
    
    notificationToggles.forEach(toggle => {
        toggle.addEventListener('change', function() {
            const notificationType = this.getAttribute('data-notification-type');
            const isEnabled = this.checked;
            
            // Show saving indicator
            const statusIndicator = document.createElement('span');
            statusIndicator.classList.add('text-xs', 'text-gray-500', 'ml-2', 'saving-indicator');
            statusIndicator.textContent = 'Saving...';
            
            const label = this.closest('label');
            if (label) {
                label.appendChild(statusIndicator);
            }
            
            // Simulate API call to update notification preference
            setTimeout(() => {
                // Update UI to show saved state
                if (statusIndicator) {
                    statusIndicator.textContent = 'Saved';
                    statusIndicator.classList.remove('text-gray-500');
                    statusIndicator.classList.add('text-green-500');
                    
                    // Remove indicator after a delay
                    setTimeout(() => {
                        statusIndicator.classList.add('opacity-0');
                        setTimeout(() => {
                            statusIndicator.remove();
                        }, 300);
                    }, 1500);
                }
                
                // Show toast notification
                if (typeof showToast === 'function') {
                    showToast(`${notificationType} notifications ${isEnabled ? 'enabled' : 'disabled'}`, 'success');
                }
            }, 1000);
        });
    });
}

/**
 * Initialize security settings
 */
function initSecuritySettings() {
    const changePasswordForm = document.getElementById('change-password-form');
    const twoFactorToggle = document.getElementById('two-factor-toggle');
    const twoFactorSetupSection = document.getElementById('two-factor-setup');
    
    // Password change form validation
    if (changePasswordForm) {
        changePasswordForm.addEventListener('submit', function(e) {
            let isValid = true;
            
            // Clear previous error messages
            const errorMessages = changePasswordForm.querySelectorAll('.error-message');
            errorMessages.forEach(el => el.remove());
            
            // Reset input styles
            const inputs = changePasswordForm.querySelectorAll('input');
            inputs.forEach(input => {
                input.classList.remove('border-red-500', 'bg-red-50');
            });
            
            // Validate current password
            const currentPassword = document.getElementById('current-password');
            if (currentPassword && !currentPassword.value) {
                isValid = false;
                showValidationError(currentPassword, 'Please enter your current password');
            }
            
            // Validate new password
            const newPassword = document.getElementById('new-password');
            if (newPassword && newPassword.value.length < 8) {
                isValid = false;
                showValidationError(newPassword, 'Password must be at least 8 characters');
            }
            
            // Validate password confirmation
            const confirmPassword = document.getElementById('confirm-password');
            if (confirmPassword && newPassword && confirmPassword.value !== newPassword.value) {
                isValid = false;
                showValidationError(confirmPassword, 'Passwords do not match');
            }
            
            // If validation fails, prevent form submission
            if (!isValid) {
                e.preventDefault();
                
                // Show toast notification
                if (typeof showToast === 'function') {
                    showToast('Please fix the errors in the form before submitting', 'error');
                }
            } else {
                // Show loading state
                const submitBtn = changePasswordForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = `
                    <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Changing Password...
                `;
                
                // Simulate password change
                setTimeout(() => {
                    // Reset form
                    changePasswordForm.reset();
                    
                    // Reset button
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                    
                    // Show success toast
                    if (typeof showToast === 'function') {
                        showToast('Password changed successfully!', 'success');
                    }
                }, 2000);
                
                // Prevent actual form submission for the demo
                e.preventDefault();
            }
        });
        
        function showValidationError(element, message) {
            // Highlight input
            element.classList.add('border-red-500', 'bg-red-50');
            
            // Add error message
            const errorMessage = document.createElement('p');
            errorMessage.classList.add('text-red-500', 'text-sm', 'mt-1', 'error-message', 'animate-fade-in');
            errorMessage.textContent = message;
            
            // Insert after the element or its parent label/container
            const container = element.closest('.form-group') || element.parentNode;
            container.appendChild(errorMessage);
        }
    }
    
    // Toggle 2FA setup section
    if (twoFactorToggle && twoFactorSetupSection) {
        twoFactorToggle.addEventListener('change', function() {
            if (this.checked) {
                // Show 2FA setup section
                twoFactorSetupSection.classList.remove('hidden');
                twoFactorSetupSection.classList.add('animate-fade-in');
                
                // Generate and display QR code (simulated)
                const qrCodeContainer = document.getElementById('two-factor-qr');
                if (qrCodeContainer) {
                    qrCodeContainer.innerHTML = `
                        <div class="flex justify-center py-6">
                            <svg class="animate-spin h-10 w-10 text-primary-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </div>
                    `;
                    
                    // Simulate loading QR code
                    setTimeout(() => {
                        // For demo purposes, use a placeholder QR code
                        qrCodeContainer.innerHTML = `
                            <div class="p-4 bg-white rounded-lg inline-block">
                                <svg xmlns="http://www.w3.org/2000/svg" width="150" height="150" viewBox="0 0 29 29">
                                    <path d="M1,1h7v7h-7z M10,1h2v1h1v1h-2v-1h-1z M14,1h1v2h2v1h-1v1h-1v-1h-1v-1h-1v-1h1z M17,1h1v1h1v1h-3v-1h1z M21,1h7v7h-7z M2,2v5h5v-5z M22,2v5h5v-5z M3,3h3v3h-3z M23,3h3v3h-3z M10,3h1v1h1v1h-2z M14,3h1v1h-1z M19,3h1v1h-1z M8,4h1v1h-1z M16,4h1v2h1v1h-1v1h-1v-1h-1v-1h1z M18,4h1v1h-1z M16,5h1v1h-1z M19,5h2v2h-1v-1h-1z M10,6h1v2h-2v-1h1z M12,6h2v1h1v1h-4v-1h1z M8,7h1v1h1v1h-2z M18,7h1v1h-1z M21,7h1v1h-1z M1,10h1v1h-1z M3,10h5v1h1v1h-2v1h-1v-1h-1v1h-1v-3h-1z M11,10h1v1h-1z M13,10h1v1h-1z M18,10h2v4h-1v-1h-2v-1h1z M21,10h2v1h-2z M24,10h2v1h1v1h-2v-1h-1z M27,10h1v1h-1z M9,11h1v1h-1z M15,11h2v1h-2z M23,11h1v2h-1v2h-1v-1h-2v-1h3z M27,11h1v1h-1z M3,12h1v1h-1z M6,12h2v1h-2z M11,12h1v1h-1z M13,12h2v1h-2z M17,12h1v1h-1z M25,12h2v1h-2z M1,13h2v1h-2z M4,13h1v3h1v1h-2z M9,13h1v2h-1z M13,13h2v1h1v1h-1v3h-1v-2h-1z M19,13h1v1h-1z M26,13h2v2h-1v-1h-1z M8,14h1v1h-1z M10,14h2v1h1v2h-1v-1h-2z M18,14h1v1h-1z M20,14h1v1h-1z M27,15h1v1h-1z M1,16h1v1h-1z M3,16h1v1h-1z M6,16h2v1h-2z M16,16h3v1h1v1h-4z M21,16h2v1h-2z M24,16h1v1h-1z M26,16h1v1h-1z M2,17h1v1h-1z M5,17h1v1h-1z M7,17h1v1h-1z M11,17h1v1h-1z M13,17h1v2h-1z M20,17h1v2h-1z M22,17h2v1h-2z M25,17h1v1h-1z M1,18h1v1h-1z M3,18h2v1h-2z M8,18h1v1h-1z M15,18h1v1h-1z M17,18h1v1h-1z M23,18h4v1h-4z M7,19h1v1h-1z M9,19h2v1h-2z M12,19h1v1h-1z M14,19h1v1h1v3h-1v1h-1v-1h-1v-1h1z M16,19h1v1h-1z M18,19h1v1h-1z M21,19h1v1h-1z M24,19h1v1h-1z M26,19h1v1h-1z M1,21h7v7h-7z M10,21h1v1h-1z M13,21h1v2h-1z M16,21h1v2h1v1h-2z M19,21h4v1h-2v1h-1v-1h-1z M24,21h1v1h-1z M27,21h1v1h-1z M2,22v5h5v-5z M9,22h1v4h-1v1h-2v-1h1v-1h-1v-1h1v-1h1z M12,22h1v1h-1z M20,22h1v1h1v2h-1v-1h-2v-1h1z M22,22h2v3h-1v-2h-1z M25,22h2v1h-1v3h-1v-2h-1v-1h1z M3,23h3v3h-3z M11,23h1v1h-1z M27,23h1v2h-1z M15,24h1v1h-1z M17,24h2v1h-2z M11,25h2v1h-1v1h-1z M13,25h1v1h-1z M15,25h1v2h-1z M19,25h1v1h-1z M24,25h1v2h-4v-1h3z M14,26h1v1h-1z M16,26h2v1h-2z M19,26h2v1h-2z M26,26h2v2h-3v-1h1z M22,27h1v1h-1z" fill="#000000"/>
                                </svg>
                            </div>
                            <p class="text-gray-500 text-sm mt-2">Scan this QR code with your authenticator app</p>
                            <p class="text-gray-500 text-sm mt-1">Your security key: ABCD-EFGH-IJKL-MNOP</p>
                        `;
                    }, 1500);
                }
            } else {
                // Hide 2FA setup section with animation
                twoFactorSetupSection.classList.remove('animate-fade-in');
                twoFactorSetupSection.classList.add('animate-fade-out');
                
                setTimeout(() => {
                    twoFactorSetupSection.classList.add('hidden');
                    twoFactorSetupSection.classList.remove('animate-fade-out');
                }, 300);
                
                // Show confirmation toast
                if (typeof showToast === 'function') {
                    showToast('Two-factor authentication disabled', 'info');
                }
            }
        });
    }
}

/**
 * Initialize transaction history
 */
function initTransactionHistory() {
    const transactionFilter = document.getElementById('transaction-filter');
    const dateRangeFilter = document.getElementById('date-range-filter');
    const transactionItems = document.querySelectorAll('.transaction-item');
    
    // Filter transactions by type
    if (transactionFilter) {
        transactionFilter.addEventListener('change', function() {
            filterTransactions();
        });
    }
    
    // Filter transactions by date range
    if (dateRangeFilter) {
        dateRangeFilter.addEventListener('change', function() {
            filterTransactions();
        });
    }
    
    function filterTransactions() {
        const typeFilter = transactionFilter ? transactionFilter.value : 'all';
        const dateFilter = dateRangeFilter ? dateRangeFilter.value : 'all';
        
        let hasVisibleTransactions = false;
        
        transactionItems.forEach(item => {
            const transactionType = item.getAttribute('data-type');
            const transactionDate = new Date(item.getAttribute('data-date'));
            
            let typeMatch = typeFilter === 'all' || transactionType === typeFilter;
            let dateMatch = true;
            
            // Apply date filtering
            if (dateFilter !== 'all') {
                const today = new Date();
                const yesterday = new Date(today);
                yesterday.setDate(yesterday.getDate() - 1);
                
                const thisWeekStart = new Date(today);
                thisWeekStart.setDate(today.getDate() - today.getDay());
                
                const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
                
                if (dateFilter === 'today') {
                    dateMatch = transactionDate.toDateString() === today.toDateString();
                } else if (dateFilter === 'yesterday') {
                    dateMatch = transactionDate.toDateString() === yesterday.toDateString();
                } else if (dateFilter === 'this-week') {
                    dateMatch = transactionDate >= thisWeekStart;
                } else if (dateFilter === 'this-month') {
                    dateMatch = transactionDate >= thisMonthStart;
                }
            }
            
            if (typeMatch && dateMatch) {
                item.classList.remove('hidden');
                hasVisibleTransactions = true;
            } else {
                item.classList.add('hidden');
            }
        });
        
        // Show or hide empty state
        const emptyState = document.getElementById('transactions-empty-state');
        if (emptyState) {
            if (hasVisibleTransactions) {
                emptyState.classList.add('hidden');
            } else {
                emptyState.classList.remove('hidden');
                emptyState.classList.add('animate-fade-in');
            }
        }
    }
}

/**
 * Initialize avatar upload functionality
 */
function initAvatarUpload() {
    const avatarUpload = document.getElementById('avatar-upload');
    const avatarPreview = document.getElementById('avatar-preview');
    const avatarInput = document.getElementById('avatar-input');
    
    if (!avatarUpload || !avatarPreview) return;
    
    // Show file picker when clicking on avatar
    avatarUpload.addEventListener('click', function() {
        if (avatarInput) {
            avatarInput.click();
        }
    });
    
    // Handle avatar image preview
    if (avatarInput) {
        avatarInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    // Update avatar preview
                    if (avatarPreview.tagName.toLowerCase() === 'img') {
                        avatarPreview.src = e.target.result;
                    } else {
                        avatarPreview.style.backgroundImage = `url(${e.target.result})`;
                    }
                    
                    // Add animation
                    avatarPreview.classList.add('scale-110');
                    setTimeout(() => {
                        avatarPreview.classList.remove('scale-110');
                    }, 300);
                    
                    // Show toast notification
                    if (typeof showToast === 'function') {
                        showToast('Avatar updated! Save your profile to apply changes.', 'success');
                    }
                };
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
}
