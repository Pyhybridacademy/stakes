/**
 * Mobile menu functionality for CardTrade platform
 * Handles the opening and closing of the mobile navigation menu
 */

document.addEventListener('DOMContentLoaded', function() {
    // Setup mobile menu toggle
    const mobileMenuButton = document.querySelector('.mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuButton && mobileMenu) {
        // Toggle menu when button is clicked
        mobileMenuButton.addEventListener('click', function() {
            // Toggle the 'hidden' class
            mobileMenu.classList.toggle('hidden');
            
            // Toggle the menu icons
            const openIcon = mobileMenuButton.querySelector('.block');
            const closeIcon = mobileMenuButton.querySelector('.hidden');
            
            if (openIcon && closeIcon) {
                openIcon.classList.toggle('block');
                openIcon.classList.toggle('hidden');
                closeIcon.classList.toggle('block');
                closeIcon.classList.toggle('hidden');
            }
            
            // Add animation classes if menu is now visible
            if (!mobileMenu.classList.contains('hidden')) {
                mobileMenu.classList.add('animate-slide-in');
            }
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuButton.contains(event.target) && 
                !mobileMenu.contains(event.target) && 
                !mobileMenu.classList.contains('hidden')) {
                
                mobileMenu.classList.add('animate-fade-out');
                
                setTimeout(() => {
                    mobileMenu.classList.add('hidden');
                    mobileMenu.classList.remove('animate-fade-out');
                    
                    // Reset the button icons
                    const openIcon = mobileMenuButton.querySelector('.hidden');
                    const closeIcon = mobileMenuButton.querySelector('.block');
                    
                    if (openIcon && openIcon !== closeIcon) {
                        openIcon.classList.remove('hidden');
                        openIcon.classList.add('block');
                        closeIcon.classList.remove('block');
                        closeIcon.classList.add('hidden');
                    }
                }, 300);
            }
        });
        
        // Handle swipe gestures on mobile
        handleSwipeGesture();
    }
    
    /**
     * Handle swipe gestures for opening and closing the mobile menu
     */
    function handleSwipeGesture() {
        let touchStartX = 0;
        let touchEndX = 0;
        
        // Minimum horizontal swipe distance required (in px)
        const minSwipeDistance = 50;
        
        // Add touch event listeners to body
        document.body.addEventListener('touchstart', function(event) {
            touchStartX = event.changedTouches[0].screenX;
        }, false);
        
        document.body.addEventListener('touchend', function(event) {
            touchEndX = event.changedTouches[0].screenX;
            handleSwipe();
        }, false);
        
        // Handle swipe logic
        function handleSwipe() {
            // Calculate swipe distance
            const swipeDistance = touchEndX - touchStartX;
            
            // If swipe distance is not significant, ignore
            if (Math.abs(swipeDistance) < minSwipeDistance) {
                return;
            }
            
            // Right to left swipe (close menu)
            if (swipeDistance < 0 && !mobileMenu.classList.contains('hidden')) {
                mobileMenu.classList.add('animate-fade-out');
                
                setTimeout(() => {
                    mobileMenu.classList.add('hidden');
                    mobileMenu.classList.remove('animate-fade-out');
                    
                    // Reset the button icons
                    const openIcon = mobileMenuButton.querySelector('.hidden');
                    const closeIcon = mobileMenuButton.querySelector('.block');
                    
                    if (openIcon && openIcon !== closeIcon) {
                        openIcon.classList.remove('hidden');
                        openIcon.classList.add('block');
                        closeIcon.classList.remove('block');
                        closeIcon.classList.add('hidden');
                    }
                }, 300);
            }
            
            // Left to right swipe (open menu)
            if (swipeDistance > 0 && mobileMenu.classList.contains('hidden')) {
                mobileMenu.classList.remove('hidden');
                mobileMenu.classList.add('animate-slide-in');
                
                // Update the button icons
                const openIcon = mobileMenuButton.querySelector('.block');
                const closeIcon = mobileMenuButton.querySelector('.hidden');
                
                if (openIcon && closeIcon) {
                    openIcon.classList.remove('block');
                    openIcon.classList.add('hidden');
                    closeIcon.classList.remove('hidden');
                    closeIcon.classList.add('block');
                }
            }
        }
    }
});