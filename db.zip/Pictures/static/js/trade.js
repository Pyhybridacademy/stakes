/**
 * Trade functionality for the CardTrade platform
 * Handles gift card trading operations, forms, and validation
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize trade creation form
    initTradeForm();
    
    // Initialize trade rate calculator
    initRateCalculator();
    
    // Initialize image preview for gift card uploads
    initImagePreview();
    
    // Initialize trade confirmation modal
    initTradeConfirmation();
    
    // Setup trade status updates
    initTradeStatusUpdates();
});

/**
 * Initialize and manage the trade creation form
 */
function initTradeForm() {
    const tradeForm = document.getElementById('trade-form');
    if (!tradeForm) return;
    
    const categorySelect = document.getElementById('category');
    const subcategorySelect = document.getElementById('subcategory');
    const valueInput = document.getElementById('card_value');
    const cardCodeInput = document.getElementById('card_code');
    const cardPinInput = document.getElementById('card_pin');
    const estimatedValueDisplay = document.getElementById('estimated_value');
    const submitButton = document.getElementById('submit-trade');
    
    // Dynamic subcategory loading when category changes
    if (categorySelect) {
        categorySelect.addEventListener('change', function() {
            const categoryId = this.value;
            
            if (categoryId && subcategorySelect) {
                // Reset the subcategory dropdown
                subcategorySelect.innerHTML = '<option value="">Loading options...</option>';
                subcategorySelect.disabled = true;
                
                // Show loading indicator
                subcategorySelect.classList.add('animate-pulse');
                
                // In a real application, this would fetch subcategories via AJAX
                // For the demo, we'll simulate the loading delay
                setTimeout(() => {
                    // Remove loading state
                    subcategorySelect.classList.remove('animate-pulse');
                    subcategorySelect.disabled = false;
                    
                    // For demonstration, populate with example subcategories
                    // In a real app, these would come from an API response
                    const categoryData = {
                        'amazon': ['Amazon US', 'Amazon UK', 'Amazon CA', 'Amazon Gift Card Email Delivery'],
                        'apple': ['App Store', 'iTunes', 'Apple Store'],
                        'google': ['Google Play', 'Google Store'],
                        'visa': ['Visa Gift Card', 'Visa Prepaid', 'Visa Virtual Card'],
                        'steam': ['Steam Wallet', 'Steam Game'],
                        'walmart': ['Walmart eGift', 'Walmart Physical Card'],
                        'target': ['Target eGift', 'Target Physical Card'],
                        'playstation': ['PlayStation Plus', 'PlayStation Store'],
                        'xbox': ['Xbox Game Pass', 'Xbox Live Gold', 'Xbox Store'],
                        'bestbuy': ['Best Buy eGift', 'Best Buy Physical Card']
                    };
                    
                    // Lookup subcategories based on selected category
                    const selectedCategory = categoryId.toLowerCase();
                    const subcategories = categoryData[selectedCategory] || [];
                    
                    subcategorySelect.innerHTML = '<option value="">Select subcategory</option>';
                    
                    subcategories.forEach((subcategory, index) => {
                        const option = document.createElement('option');
                        option.value = index + 1; // Simulated ID
                        option.textContent = subcategory;
                        subcategorySelect.appendChild(option);
                    });
                    
                    // If no subcategories available
                    if (subcategories.length === 0) {
                        subcategorySelect.innerHTML = '<option value="">No subcategories available</option>';
                    }
                }, 800);
            }
        });
    }
    
    // Real-time trade value estimation
    if (valueInput && estimatedValueDisplay) {
        valueInput.addEventListener('input', updateEstimatedValue);
        
        if (categorySelect) {
            categorySelect.addEventListener('change', updateEstimatedValue);
        }
        
        function updateEstimatedValue() {
            const cardValue = parseFloat(valueInput.value) || 0;
            const categoryId = categorySelect ? categorySelect.value : '';
            
            if (cardValue > 0) {
                // Simulate calculating estimated value based on card value and category
                // In a real app, this might involve an API call to get current rates
                const mockRates = {
                    'amazon': 0.85,
                    'apple': 0.80,
                    'google': 0.82,
                    'visa': 0.90,
                    'steam': 0.75,
                    'walmart': 0.80,
                    'target': 0.78,
                    'playstation': 0.70,
                    'xbox': 0.72,
                    'bestbuy': 0.76
                };
                
                const rate = mockRates[categoryId.toLowerCase()] || 0.75;
                const estimatedValue = cardValue * rate;
                
                // Format and display the estimated value
                estimatedValueDisplay.textContent = formatCurrency(estimatedValue);
                estimatedValueDisplay.classList.add('text-green-600', 'font-semibold');
                
                // Add animation to highlight value update
                estimatedValueDisplay.classList.add('animate-pulse');
                setTimeout(() => {
                    estimatedValueDisplay.classList.remove('animate-pulse');
                }, 500);
            } else {
                estimatedValueDisplay.textContent = '$0.00';
                estimatedValueDisplay.classList.remove('text-green-600', 'font-semibold');
            }
        }
    }
    
    // Form validation
    if (tradeForm) {
        tradeForm.addEventListener('submit', function(e) {
            let isValid = true;
            
            // Clear previous error states
            const errorMessages = tradeForm.querySelectorAll('.error-message');
            errorMessages.forEach(el => el.remove());
            
            const inputs = tradeForm.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                input.classList.remove('border-red-500', 'bg-red-50');
            });
            
            // Validate category
            if (categorySelect && categorySelect.value === '') {
                isValid = false;
                showValidationError(categorySelect, 'Please select a card category');
            }
            
            // Validate card value
            if (valueInput && (valueInput.value === '' || parseFloat(valueInput.value) <= 0)) {
                isValid = false;
                showValidationError(valueInput, 'Please enter a valid card value');
            }
            
            // Validate card code
            if (cardCodeInput && cardCodeInput.value.trim() === '') {
                isValid = false;
                showValidationError(cardCodeInput, 'Please enter the gift card code');
            }
            
            // Only some cards require a PIN, so only validate if visible
            const pinField = cardPinInput ? cardPinInput.closest('.form-group') : null;
            if (pinField && !pinField.classList.contains('hidden') && cardPinInput.value.trim() === '') {
                isValid = false;
                showValidationError(cardPinInput, 'Please enter the gift card PIN');
            }
            
            // Image validation (if using file upload)
            const cardImageInput = document.getElementById('card_image');
            if (cardImageInput && cardImageInput.files.length === 0) {
                isValid = false;
                showValidationError(cardImageInput, 'Please upload an image of your gift card');
            }
            
            // If validation fails, prevent form submission
            if (!isValid) {
                e.preventDefault();
                
                // Scroll to the first error
                const firstError = tradeForm.querySelector('.error-message');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                
                // Show toast notification
                if (typeof showToast === 'function') {
                    showToast('Please fix the errors in the form before submitting', 'error');
                }
            } else {
                // If form is valid, show loading state
                if (submitButton) {
                    submitButton.disabled = true;
                    
                    const originalText = submitButton.innerHTML;
                    submitButton.innerHTML = `
                        <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Processing...
                    `;
                    
                    // In case form submission takes too long, reset button after timeout
                    setTimeout(() => {
                        submitButton.disabled = false;
                        submitButton.innerHTML = originalText;
                    }, 10000);
                }
            }
        });
        
        function showValidationError(element, message) {
            // Highlight input
            element.classList.add('border-red-500', 'bg-red-50');
            
            // Add error message
            const errorMessage = document.createElement('p');
            errorMessage.classList.add('text-red-500', 'text-sm', 'mt-1', 'error-message', 'animate-fade-in');
            errorMessage.textContent = message;
            
            // Insert after the element or its parent label/container
            const container = element.closest('.form-group') || element.parentNode;
            container.appendChild(errorMessage);
            
            // Add shake animation to element
            element.classList.add('shake');
            setTimeout(() => {
                element.classList.remove('shake');
            }, 500);
        }
    }
    
    // Toggle PIN field visibility based on card type
    if (categorySelect) {
        categorySelect.addEventListener('change', function() {
            const pinRequiredCategories = ['visa', 'mastercard', 'vanilla'];
            const selectedCategory = this.value.toLowerCase();
            
            const pinField = document.getElementById('pin-field');
            if (pinField) {
                if (pinRequiredCategories.some(cat => selectedCategory.includes(cat))) {
                    pinField.classList.remove('hidden');
                } else {
                    pinField.classList.add('hidden');
                }
            }
        });
    }
}

/**
 * Initialize the rate calculator widget
 */
function initRateCalculator() {
    const rateCalculator = document.getElementById('rate-calculator');
    if (!rateCalculator) return;
    
    const calcCategorySelect = document.getElementById('calc_category');
    const calcValueInput = document.getElementById('calc_value');
    const calcButton = document.getElementById('calculate-rate-btn');
    const resultDisplay = document.getElementById('calculation-result');
    
    if (calcButton) {
        calcButton.addEventListener('click', function(e) {
            e.preventDefault();
            
            const category = calcCategorySelect ? calcCategorySelect.value : '';
            const value = parseFloat(calcValueInput ? calcValueInput.value : 0) || 0;
            
            if (category && value > 0) {
                // Simulate calculating value
                const mockRates = {
                    'amazon': 0.85,
                    'apple': 0.80,
                    'google': 0.82,
                    'visa': 0.90,
                    'steam': 0.75,
                    'walmart': 0.80,
                    'target': 0.78,
                    'playstation': 0.70,
                    'xbox': 0.72,
                    'bestbuy': 0.76
                };
                
                const rate = mockRates[category.toLowerCase()] || 0.75;
                const estimatedValue = value * rate;
                
                if (resultDisplay) {
                    // Hide the result first
                    resultDisplay.style.opacity = '0';
                    
                    // Add loading indicator
                    resultDisplay.innerHTML = `
                        <div class="flex items-center justify-center py-4">
                            <svg class="animate-spin h-5 w-5 text-primary-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        </div>
                    `;
                    resultDisplay.style.opacity = '1';
                    
                    // Simulate API response time
                    setTimeout(() => {
                        // Format and display the result
                        resultDisplay.innerHTML = `
                            <div class="text-center py-4">
                                <div class="text-lg font-semibold mb-2">Estimated Value</div>
                                <div class="text-3xl font-bold text-primary-600 mb-2">${formatCurrency(estimatedValue)}</div>
                                <div class="text-sm text-gray-500">Rate: ${(rate * 100).toFixed(0)}%</div>
                                
                                <div class="mt-4">
                                    <a href="/create_trade/?category=${category}&value=${value}" class="btn btn-primary">
                                        Sell this Card Now
                                    </a>
                                </div>
                            </div>
                        `;
                        
                        // Add entrance animation
                        resultDisplay.style.opacity = '0';
                        setTimeout(() => {
                            resultDisplay.style.opacity = '1';
                            resultDisplay.classList.add('animate-slide-in');
                        }, 50);
                    }, 1200);
                }
            } else {
                if (resultDisplay) {
                    // Show error message
                    resultDisplay.innerHTML = `
                        <div class="bg-red-50 text-red-800 p-4 rounded-md text-center">
                            <p>Please select a category and enter a valid card value.</p>
                        </div>
                    `;
                    
                    resultDisplay.classList.add('animate-shake');
                    setTimeout(() => {
                        resultDisplay.classList.remove('animate-shake');
                    }, 500);
                }
            }
        });
    }
}

/**
 * Initialize image preview for gift card uploads
 */
function initImagePreview() {
    const imageUpload = document.getElementById('card_image');
    const previewContainer = document.getElementById('image-preview');
    
    if (!imageUpload || !previewContainer) return;
    
    imageUpload.addEventListener('change', function() {
        // Clear previous preview
        previewContainer.innerHTML = '';
        
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                previewContainer.innerHTML = `
                    <div class="relative">
                        <img src="${e.target.result}" alt="Card Preview" class="max-h-64 rounded-lg shadow-sm">
                        <button type="button" id="remove-image" class="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 shadow-sm hover:bg-red-600 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </button>
                    </div>
                `;
                
                // Add animation to preview
                previewContainer.classList.add('animate-fade-in');
                
                // Add remove button functionality
                const removeButton = document.getElementById('remove-image');
                if (removeButton) {
                    removeButton.addEventListener('click', function() {
                        previewContainer.innerHTML = '';
                        imageUpload.value = '';
                    });
                }
            };
            
            reader.readAsDataURL(this.files[0]);
        }
    });
}

/**
 * Initialize trade confirmation modal
 */
function initTradeConfirmation() {
    const confirmModal = document.getElementById('trade-confirm-modal');
    if (!confirmModal) return;
    
    const confirmOpenButtons = document.querySelectorAll('[data-confirm="open"]');
    const confirmCloseButtons = document.querySelectorAll('[data-confirm="close"]');
    const confirmProceedButton = document.getElementById('confirm-proceed-btn');
    
    // Open confirmation modal
    confirmOpenButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get trade details from button's data attributes
            const tradeDetails = {
                id: this.getAttribute('data-trade-id'),
                category: this.getAttribute('data-trade-category'),
                value: this.getAttribute('data-trade-value'),
                rate: this.getAttribute('data-trade-rate'),
                estimatedValue: this.getAttribute('data-trade-estimated')
            };
            
            // Populate confirmation modal with trade details
            const categoryDisplay = confirmModal.querySelector('[data-confirm-detail="category"]');
            const valueDisplay = confirmModal.querySelector('[data-confirm-detail="value"]');
            const rateDisplay = confirmModal.querySelector('[data-confirm-detail="rate"]');
            const estimatedDisplay = confirmModal.querySelector('[data-confirm-detail="estimated"]');
            
            if (categoryDisplay) categoryDisplay.textContent = tradeDetails.category || 'N/A';
            if (valueDisplay) valueDisplay.textContent = formatCurrency(parseFloat(tradeDetails.value)) || '$0.00';
            if (rateDisplay) rateDisplay.textContent = `${parseFloat(tradeDetails.rate) * 100}%` || '0%';
            if (estimatedDisplay) estimatedDisplay.textContent = formatCurrency(parseFloat(tradeDetails.estimatedValue)) || '$0.00';
            
            // Set trade ID on proceed button
            if (confirmProceedButton) {
                confirmProceedButton.setAttribute('data-trade-id', tradeDetails.id);
            }
            
            // Show the modal
            confirmModal.classList.remove('hidden');
            document.body.classList.add('overflow-hidden'); // Prevent scrolling
            
            // Add entrance animation
            setTimeout(() => {
                confirmModal.querySelector('.modal-content').classList.add('scale-100', 'opacity-100');
                confirmModal.querySelector('.modal-content').classList.remove('scale-95', 'opacity-0');
            }, 10);
        });
    });
    
    // Close confirmation modal
    confirmCloseButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Add exit animation
            confirmModal.querySelector('.modal-content').classList.remove('scale-100', 'opacity-100');
            confirmModal.querySelector('.modal-content').classList.add('scale-95', 'opacity-0');
            
            // Hide the modal after animation
            setTimeout(() => {
                confirmModal.classList.add('hidden');
                document.body.classList.remove('overflow-hidden');
            }, 300);
        });
    });
    
    // Close modal when clicking on backdrop
    confirmModal.addEventListener('click', function(e) {
        if (e.target === this) {
            // Add exit animation
            confirmModal.querySelector('.modal-content').classList.remove('scale-100', 'opacity-100');
            confirmModal.querySelector('.modal-content').classList.add('scale-95', 'opacity-0');
            
            // Hide the modal after animation
            setTimeout(() => {
                confirmModal.classList.add('hidden');
                document.body.classList.remove('overflow-hidden');
            }, 300);
        }
    });
    
    // Proceed with trade confirmation
    if (confirmProceedButton) {
        confirmProceedButton.addEventListener('click', function() {
            const tradeId = this.getAttribute('data-trade-id');
            
            // Show loading state
            this.disabled = true;
            const originalText = this.innerHTML;
            this.innerHTML = `
                <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
            `;
            
            // Simulate API call to confirm trade
            setTimeout(() => {
                // Close the modal
                confirmModal.querySelector('.modal-content').classList.remove('scale-100', 'opacity-100');
                confirmModal.querySelector('.modal-content').classList.add('scale-95', 'opacity-0');
                
                setTimeout(() => {
                    confirmModal.classList.add('hidden');
                    document.body.classList.remove('overflow-hidden');
                    
                    // Show success toast
                    if (typeof showToast === 'function') {
                        showToast('Trade submitted successfully! Your gift card is being verified.', 'success');
                    }
                    
                    // Redirect to dashboard after a short delay
                    setTimeout(() => {
                        window.location.href = '/dashboard/';
                    }, 2000);
                }, 300);
            }, 2000);
        });
    }
}

/**
 * Initialize and setup trade status updates
 */
function initTradeStatusUpdates() {
    const tradeCards = document.querySelectorAll('.trade-card');
    
    tradeCards.forEach(card => {
        const statusBadge = card.querySelector('.status-badge');
        const tradeId = card.getAttribute('data-trade-id');
        
        if (!statusBadge || !tradeId) return;
        
        // Get current status
        const currentStatus = statusBadge.getAttribute('data-status');
        
        // Only add realtime updates for pending trades
        if (currentStatus === 'pending') {
            // Simulate periodic status checks
            // In a real app, this would be handled by WebSockets or polling
            const checkInterval = Math.random() * 15000 + 10000; // Random between 10-25 seconds
            
            // Used for demo purposes only - randomize if the trade will complete or not
            const willVerify = Math.random() > 0.3; // 70% chance of verification
            
            setTimeout(() => {
                if (willVerify) {
                    // Update to verified status
                    statusBadge.textContent = 'Verified';
                    statusBadge.classList.remove('bg-yellow-100', 'text-yellow-800');
                    statusBadge.classList.add('bg-green-100', 'text-green-800', 'animate-pulse');
                    
                    // Update status attribute
                    statusBadge.setAttribute('data-status', 'verified');
                    
                    // Show notification
                    if (typeof showToast === 'function') {
                        showToast(`Trade #${tradeId} has been verified!`, 'success');
                    }
                    
                    // Stop the pulse animation after a few seconds
                    setTimeout(() => {
                        statusBadge.classList.remove('animate-pulse');
                    }, 5000);
                } else {
                    // Random issue - update to needs attention status
                    statusBadge.textContent = 'Needs Attention';
                    statusBadge.classList.remove('bg-yellow-100', 'text-yellow-800');
                    statusBadge.classList.add('bg-red-100', 'text-red-800', 'animate-pulse');
                    
                    // Update status attribute
                    statusBadge.setAttribute('data-status', 'issue');
                    
                    // Show notification
                    if (typeof showToast === 'function') {
                        showToast(`Trade #${tradeId} needs your attention`, 'warning');
                    }
                    
                    // Stop the pulse animation after a few seconds
                    setTimeout(() => {
                        statusBadge.classList.remove('animate-pulse');
                    }, 5000);
                }
            }, checkInterval);
        }
    });
}

// Utility function for formatting currency (if not already defined in main.js)
function formatCurrency(amount, currency = 'USD') {
    if (typeof window.formatCurrency === 'function') {
        return window.formatCurrency(amount, currency);
    }
    
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency
    }).format(amount);
}
