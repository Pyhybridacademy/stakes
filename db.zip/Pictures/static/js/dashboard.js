/**
 * Dashboard specific JavaScript functionality
 */
document.addEventListener('DOMContentLoaded', function() {
    // Balance visualizations
    initializeBalanceChart();
    
    // Trade history filter functionality
    initializeTradeFilters();
    
    // Initialize stats counters
    initializeCounters();
    
    // Notification handling
    initializeNotifications();
    
    // Recent activity auto-refresh
    setupActivityRefresh();
    
    // Handle card hover effects
    setupCardInteractions();
});

/**
 * Initialize balance chart using Chart.js
 */
function initializeBalanceChart() {
    const balanceChart = document.getElementById('balance-chart');
    if (!balanceChart) return;
    
    // Check if Chart.js is loaded
    if (typeof Chart === 'undefined') {
        // Load Chart.js from CDN
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/chart.js@3.7.1/dist/chart.min.js';
        script.onload = createChart;
        document.head.appendChild(script);
    } else {
        createChart();
    }
    
    function createChart() {
        // Get balance data from the element's data attributes
        const balanceData = JSON.parse(balanceChart.getAttribute('data-balance') || '[]');
        const dates = balanceData.map(item => item.date);
        const amounts = balanceData.map(item => item.amount);
        
        // Create the chart
        new Chart(balanceChart, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: 'Account Balance',
                    data: amounts,
                    backgroundColor: 'rgba(14, 165, 233, 0.2)',
                    borderColor: 'rgba(14, 165, 233, 1)',
                    borderWidth: 2,
                    tension: 0.2,
                    fill: true,
                    pointBackgroundColor: 'rgba(14, 165, 233, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(17, 24, 39, 0.9)',
                        padding: 12,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        callbacks: {
                            label: function(context) {
                                return `Balance: ${formatCurrency(context.raw)}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(156, 163, 175, 0.1)',
                        },
                        ticks: {
                            callback: function(value) {
                                return formatCurrency(value);
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            maxRotation: 45,
                            minRotation: 45
                        }
                    }
                },
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                }
            }
        });
    }
}

/**
 * Initialize trade history filters
 */
function initializeTradeFilters() {
    const filterForm = document.getElementById('trade-filter-form');
    if (!filterForm) return;
    
    const filterInputs = filterForm.querySelectorAll('select, input');
    const tradeItems = document.querySelectorAll('.trade-item');
    const tradeTypeFilter = document.getElementById('filter-trade-type');
    const tradeStatusFilter = document.getElementById('filter-trade-status');
    const tradeDateFilter = document.getElementById('filter-trade-date');
    const resetFilterBtn = document.getElementById('reset-filter-btn');
    
    // Apply filters when any input changes
    filterInputs.forEach(input => {
        input.addEventListener('change', applyFilters);
    });
    
    // Reset filters button
    if (resetFilterBtn) {
        resetFilterBtn.addEventListener('click', function(e) {
            e.preventDefault();
            filterForm.reset();
            applyFilters();
        });
    }
    
    function applyFilters() {
        const typeValue = tradeTypeFilter ? tradeTypeFilter.value : '';
        const statusValue = tradeStatusFilter ? tradeStatusFilter.value : '';
        const dateValue = tradeDateFilter ? tradeDateFilter.value : '';
        
        tradeItems.forEach(item => {
            const itemType = item.getAttribute('data-type');
            const itemStatus = item.getAttribute('data-status');
            const itemDate = item.getAttribute('data-date');
            
            let typeMatch = true;
            let statusMatch = true;
            let dateMatch = true;
            
            if (typeValue && typeValue !== 'all') {
                typeMatch = itemType === typeValue;
            }
            
            if (statusValue && statusValue !== 'all') {
                statusMatch = itemStatus === statusValue;
            }
            
            if (dateValue) {
                const filterDate = new Date(dateValue);
                const itemDateTime = new Date(itemDate);
                dateMatch = 
                    itemDateTime.getFullYear() === filterDate.getFullYear() && 
                    itemDateTime.getMonth() === filterDate.getMonth() && 
                    itemDateTime.getDate() === filterDate.getDate();
            }
            
            if (typeMatch && statusMatch && dateMatch) {
                item.classList.remove('hidden');
            } else {
                item.classList.add('hidden');
            }
        });
        
        // Show or hide empty state
        const visibleItems = document.querySelectorAll('.trade-item:not(.hidden)');
        const emptyState = document.getElementById('trades-empty-state');
        
        if (emptyState) {
            if (visibleItems.length === 0) {
                emptyState.classList.remove('hidden');
            } else {
                emptyState.classList.add('hidden');
            }
        }
    }
}

/**
 * Initialize animated counters for dashboard stats
 */
function initializeCounters() {
    const counterElements = document.querySelectorAll('[data-counter]');
    
    counterElements.forEach(element => {
        const targetValue = parseFloat(element.getAttribute('data-counter'));
        const prefix = element.getAttribute('data-prefix') || '';
        const suffix = element.getAttribute('data-suffix') || '';
        const duration = parseInt(element.getAttribute('data-duration') || '1000');
        
        let startTime = null;
        const startValue = 0;
        
        function updateCounter(timestamp) {
            if (!startTime) startTime = timestamp;
            
            const progress = Math.min((timestamp - startTime) / duration, 1);
            const currentValue = startValue + (targetValue - startValue) * easeOutQuad(progress);
            
            if (Number.isInteger(targetValue)) {
                element.textContent = prefix + Math.floor(currentValue) + suffix;
            } else {
                element.textContent = prefix + currentValue.toFixed(2) + suffix;
            }
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            }
        }
        
        function easeOutQuad(t) {
            return t * (2 - t);
        }
        
        // Start the animation when the element is in viewport
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    requestAnimationFrame(updateCounter);
                    observer.unobserve(entry.target);
                }
            });
        });
        
        observer.observe(element);
    });
}

/**
 * Initialize notifications system
 */
function initializeNotifications() {
    const notificationBell = document.getElementById('notification-bell');
    const notificationPanel = document.getElementById('notification-panel');
    const notificationBadge = document.getElementById('notification-badge');
    const notificationItems = document.querySelectorAll('.notification-item');
    const markAllReadBtn = document.getElementById('mark-all-read');
    
    if (!notificationBell || !notificationPanel) return;
    
    // Toggle notification panel visibility
    notificationBell.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        notificationPanel.classList.toggle('hidden');
        
        // Mark as seen when opened
        if (!notificationPanel.classList.contains('hidden')) {
            notificationBadge.classList.add('hidden');
        }
    });
    
    // Close panel when clicking outside
    document.addEventListener('click', function(e) {
        if (notificationPanel && !notificationPanel.classList.contains('hidden')) {
            if (!notificationPanel.contains(e.target) && e.target !== notificationBell) {
                notificationPanel.classList.add('hidden');
            }
        }
    });
    
    // Handle individual notification click
    notificationItems.forEach(item => {
        item.addEventListener('click', function() {
            const unread = this.classList.contains('bg-blue-50');
            if (unread) {
                this.classList.remove('bg-blue-50');
                updateNotificationCounter(-1);
            }
            
            // Navigate if there's a link
            const link = this.getAttribute('data-link');
            if (link) {
                window.location.href = link;
            }
        });
    });
    
    // Mark all as read button
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            notificationItems.forEach(item => {
                item.classList.remove('bg-blue-50');
            });
            
            notificationBadge.classList.add('hidden');
            notificationBadge.textContent = '0';
        });
    }
    
    function updateNotificationCounter(change) {
        if (!notificationBadge) return;
        
        let count = parseInt(notificationBadge.textContent || '0');
        count += change;
        
        notificationBadge.textContent = count.toString();
        
        if (count <= 0) {
            notificationBadge.classList.add('hidden');
        } else {
            notificationBadge.classList.remove('hidden');
        }
    }
}

/**
 * Set up auto-refresh for recent activity
 */
function setupActivityRefresh() {
    const activityContainer = document.getElementById('recent-activity');
    if (!activityContainer) return;
    
    const refreshInterval = parseInt(activityContainer.getAttribute('data-refresh-interval') || '60000');
    
    // Only fetch new activities if refresh interval is set
    if (refreshInterval > 0) {
        setInterval(fetchRecentActivity, refreshInterval);
    }
    
    function fetchRecentActivity() {
        // In a real application, this would be an AJAX call to fetch new activities
        // For now, we'll simulate with a visual refresh indicator
        const refreshIndicator = document.createElement('div');
        refreshIndicator.classList.add('text-xs', 'text-gray-500', 'text-center', 'py-1', 'animate-pulse');
        refreshIndicator.textContent = 'Refreshing...';
        
        activityContainer.insertBefore(refreshIndicator, activityContainer.firstChild);
        
        // Simulate loading delay
        setTimeout(() => {
            refreshIndicator.remove();
            
            // Add a visual indicator that activity is up to date
            const upToDateIndicator = document.createElement('div');
            upToDateIndicator.classList.add('text-xs', 'text-green-500', 'text-center', 'py-1', 'animate-fade-in');
            upToDateIndicator.textContent = 'Activity is up to date';
            
            activityContainer.insertBefore(upToDateIndicator, activityContainer.firstChild);
            
            // Remove the indicator after a few seconds
            setTimeout(() => {
                upToDateIndicator.classList.add('opacity-0');
                setTimeout(() => {
                    upToDateIndicator.remove();
                }, 300);
            }, 3000);
        }, 1000);
    }
}

/**
 * Set up card interactions for dashboard
 */
function setupCardInteractions() {
    const cards = document.querySelectorAll('.dashboard-card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.classList.add('transform', 'scale-[1.02]', 'shadow-lg');
        });
        
        card.addEventListener('mouseleave', function() {
            this.classList.remove('transform', 'scale-[1.02]', 'shadow-lg');
        });
        
        // For touch devices
        card.addEventListener('touchstart', function() {
            this.classList.add('bg-gray-50');
        });
        
        card.addEventListener('touchend', function() {
            this.classList.remove('bg-gray-50');
        });
    });
}
