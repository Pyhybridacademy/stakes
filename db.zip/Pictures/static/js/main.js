/**
 * Main JavaScript file for the Gift Card Trading Platform
 * Contains common functions used throughout the application
 */

document.addEventListener('DOMContentLoaded', function() {
    // Set body as loaded to trigger fade in animation
    setTimeout(() => {
        document.body.classList.remove('loading');
        document.body.classList.add('loaded');
    }, 100);

    // Setup message dismissal
    setupMessageDismissal();
    
    // Set up any tooltips
    setupTooltips();
});

/**
 * Set up message dismissal functionality for flash messages
 */
function setupMessageDismissal() {
    const messageCloseButtons = document.querySelectorAll('.message-close');
    
    messageCloseButtons.forEach(button => {
        button.addEventListener('click', function() {
            const message = this.closest('[role="alert"]');
            message.classList.add('animate-fade-out');
            
            setTimeout(() => {
                message.remove();
            }, 300); // Match the duration of the fade-out animation
        });
    });
}

/**
 * Set up tooltip functionality
 */
function setupTooltips() {
    const tooltipTriggers = document.querySelectorAll('[data-tooltip]');
    
    tooltipTriggers.forEach(trigger => {
        trigger.addEventListener('mouseenter', function() {
            const tooltipText = this.getAttribute('data-tooltip');
            
            // Create tooltip element
            const tooltip = document.createElement('div');
            tooltip.className = 'absolute z-50 px-2 py-1 text-xs font-medium text-white bg-gray-900 rounded shadow-sm animate-fade-in';
            tooltip.style.bottom = 'calc(100% + 5px)';
            tooltip.style.left = '50%';
            tooltip.style.transform = 'translateX(-50%)';
            tooltip.textContent = tooltipText;
            
            // Create arrow
            const arrow = document.createElement('div');
            arrow.className = 'absolute w-2 h-2 bg-gray-900 transform rotate-45';
            arrow.style.bottom = '-4px';
            arrow.style.left = 'calc(50% - 4px)';
            
            tooltip.appendChild(arrow);
            this.style.position = 'relative';
            this.appendChild(tooltip);
        });
        
        trigger.addEventListener('mouseleave', function() {
            const tooltip = this.querySelector('.animate-fade-in');
            if (tooltip) {
                tooltip.classList.add('animate-fade-out');
                setTimeout(() => {
                    tooltip.remove();
                }, 300);
            }
        });
    });
}

/**
 * Show a toast notification
 * @param {string} message - The message to display
 * @param {string} type - The type of notification (info, success, warning, error)
 * @param {number} duration - Duration in milliseconds
 */
function showToast(message, type = 'info', duration = 3000) {
    // Remove existing toasts
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create toast container if it doesn't exist
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'fixed bottom-4 right-4 z-50';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = 'toast-notification flex items-center p-4 mb-4 rounded-lg shadow-lg animate-slide-in transform transition-all duration-300';
    
    // Set background color based on type
    switch (type) {
        case 'success':
            toast.classList.add('bg-green-100', 'text-green-800');
            break;
        case 'warning':
            toast.classList.add('bg-yellow-100', 'text-yellow-800');
            break;
        case 'error':
            toast.classList.add('bg-red-100', 'text-red-800');
            break;
        default:
            toast.classList.add('bg-blue-100', 'text-blue-800');
    }
    
    // Add icon based on type
    let icon = '';
    switch (type) {
        case 'success':
            icon = '<svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>';
            break;
        case 'warning':
            icon = '<svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path></svg>';
            break;
        case 'error':
            icon = '<svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg>';
            break;
        default:
            icon = '<svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2h.01a1 1 0 100-2H9z" clip-rule="evenodd"></path></svg>';
    }
    
    // Set toast content
    toast.innerHTML = `
        <div class="flex items-center">
            ${icon}
            <div>${message}</div>
        </div>
        <button type="button" class="ml-auto -mx-1.5 -my-1.5 rounded-lg p-1.5 inline-flex items-center justify-center h-8 w-8 transition-colors hover:bg-opacity-25 hover:bg-gray-700">
            <span class="sr-only">Close</span>
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
        </button>
    `;
    
    // Append toast to container
    toastContainer.appendChild(toast);
    
    // Setup close button
    const closeButton = toast.querySelector('button');
    closeButton.addEventListener('click', () => {
        toast.classList.remove('animate-slide-in');
        toast.classList.add('animate-fade-out');
        setTimeout(() => {
            toast.remove();
        }, 300);
    });
    
    // Auto-remove after duration
    setTimeout(() => {
        if (document.body.contains(toast)) {
            toast.classList.remove('animate-slide-in');
            toast.classList.add('animate-fade-out');
            
            setTimeout(() => {
                if (document.body.contains(toast)) {
                    toast.remove();
                }
            }, 300);
        }
    }, duration);
}

/**
 * Format a number as currency
 * @param {number} amount - The amount to format
 * @param {string} currency - The currency code (Default: USD)
 * @returns {string} Formatted currency string
 */
function formatCurrency(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency
    }).format(amount);
}

/**
 * Format a date string into a human-readable format
 * @param {string} dateString - The date string to format
 * @returns {string} Formatted date string
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit'
    }).format(date);
}

/**
 * Copy text to clipboard
 * @param {string} text - The text to copy
 */
function copyToClipboard(text) {
    // Create a temporary input element
    const input = document.createElement('input');
    input.style.position = 'fixed';
    input.style.opacity = 0;
    input.value = text;
    document.body.appendChild(input);
    
    // Select and copy
    input.select();
    document.execCommand('copy');
    
    // Clean up
    document.body.removeChild(input);
    
    // Show toast
    showToast('Copied to clipboard!', 'success', 2000);
}